
import React, { useState, useEffect, useCallback } from 'react';
import { ReceiptForm } from './components/ReceiptForm';
import { ReceiptList } from './components/ReceiptList';
import { Header } from './components/Header';
import { generateReceiptPdf, printReceiptHtml, printAllReceiptsHtml } from './services/pdfService';
import type { ReceiptData, SavedReceipt } from './types';
import { defaultLogo } from './assets/logo';

const App: React.FC = () => {
    const [savedReceipts, setSavedReceipts] = useState<SavedReceipt[]>([]);

    useEffect(() => {
        try {
            const storedReceipts = localStorage.getItem('italian-security-receipts');
            if (storedReceipts) {
                setSavedReceipts(JSON.parse(storedReceipts));
            }
        } catch (error) {
            console.error("Failed to load data from localStorage:", error);
        }
    }, []);

    const getNextReceiptNumber = useCallback((): string => {
        if (savedReceipts.length === 0) {
            return "0001";
        }
        const maxId = Math.max(...savedReceipts.map(r => parseInt(r.receiptData.receiptNo, 10) || 0));
        return (maxId + 1).toString().padStart(4, '0');
    }, [savedReceipts]);

    const handleGenerateAndSave = async (receiptData: ReceiptData): Promise<string | null> => {
        try {
            const pdfBlob = await generateReceiptPdf(receiptData, defaultLogo);
            const pdfUrl = URL.createObjectURL(pdfBlob);

            const newReceipt: SavedReceipt = {
                id: Date.now(),
                pdfUrl: pdfUrl,
                receiptData: { ...receiptData }
            };

            const updatedReceipts = [newReceipt, ...savedReceipts];
            setSavedReceipts(updatedReceipts);
            localStorage.setItem('italian-security-receipts', JSON.stringify(updatedReceipts));
            
            const link = document.createElement('a');
            link.href = pdfUrl;
            link.download = `receipt_${receiptData.receiptNo}_${receiptData.date.split(' ')[0]}.pdf`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

            return pdfUrl;
        } catch (error) {
            console.error("Failed to generate PDF:", error);
            alert("An error occurred while generating the PDF. Please check the console for details.");
            return null;
        }
    };
    
    const handleDeleteReceipt = (id: number) => {
        if (window.confirm('Are you sure you want to delete this receipt? This action cannot be undone.')) {
            const updatedReceipts = savedReceipts.filter(receipt => receipt.id !== id);
            setSavedReceipts(updatedReceipts);
            localStorage.setItem('italian-security-receipts', JSON.stringify(updatedReceipts));
        }
    };

    const handlePrint = (pdfUrl: string) => {
        const iframe = document.createElement('iframe');
        iframe.style.display = 'none';
        iframe.src = pdfUrl;
        document.body.appendChild(iframe);
        iframe.onload = () => {
            setTimeout(() => {
                iframe.contentWindow?.focus();
                iframe.contentWindow?.print();
                 // Clean up after a delay
                setTimeout(() => document.body.removeChild(iframe), 1000);
            }, 1);
        };
    };

    const handleHtmlPrint = (receipt: SavedReceipt) => {
        printReceiptHtml(receipt, defaultLogo);
    };

    const handlePrintAll = () => {
        if (savedReceipts.length > 0) {
            printAllReceiptsHtml(savedReceipts, defaultLogo);
        } else {
            alert("No receipts to print.");
        }
    }


    return (
        <div className="min-h-screen bg-navy font-sans">
            <Header logo={defaultLogo} />
            <main className="container mx-auto p-4 md:p-8">
                <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
                    <div className="lg:col-span-3">
                         <ReceiptForm
                            onGenerate={handleGenerateAndSave}
                            onPrint={handlePrint}
                            nextReceiptNumber={getNextReceiptNumber()}
                        />
                    </div>
                    <div className="lg:col-span-2">
                        <ReceiptList 
                            receipts={savedReceipts} 
                            onDelete={handleDeleteReceipt} 
                            onPrint={handleHtmlPrint} 
                            onPrintAll={handlePrintAll}
                        />
                    </div>
                </div>
            </main>
             <footer className="text-center p-4 text-silver/50 text-sm mt-8">
                <p>&copy; {new Date().getFullYear()} Italian Security Services. All Rights Reserved.</p>
            </footer>
        </div>
    );
};

export default App;