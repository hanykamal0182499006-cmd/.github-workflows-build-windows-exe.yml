
import React, { useState, useEffect, useCallback } from 'react';
import type { ReceiptData } from '../types';
import { parseReceiptFromText, extractIdInfoFromImage } from '../services/geminiService';
import { AIcon, FillIcon, GenerateIcon, LoadingIcon, PrintIcon, IdCardIcon, UploadIcon } from './icons';

interface ReceiptFormProps {
    onGenerate: (data: ReceiptData) => Promise<string | null>;
    onPrint: (pdfUrl: string) => void;
    nextReceiptNumber: string;
}

const amountToWords = (num: number): string => {
    const a = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
    const b = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
    
    if (isNaN(num) || num === 0) return 'zero';
    if (num < 0) return 'minus ' + amountToWords(Math.abs(num));
    
    let words = '';
    
    const numToStr = num.toString();
    if (numToStr.length > 9) return 'overflow';
    
    const [integerPart] = numToStr.split('.');
    
    const formatGroup = (n: string) => {
        let result = '';
        const num = parseInt(n);
        if (num >= 100) {
            result += a[Math.floor(num / 100)] + ' hundred ';
        }
        const rem = num % 100;
        if (rem > 0) {
            if (rem < 20) {
                result += a[rem];
            } else {
                result += b[Math.floor(rem / 10)];
                if (rem % 10 > 0) {
                    result += ' ' + a[rem % 10];
                }
            }
        }
        return result.trim();
    };

    const padded = integerPart.padStart(Math.ceil(integerPart.length / 3) * 3, '0');
    const groups = padded.match(/.{1,3}/g) || [];
    
    const units = ['', 'thousand', 'million'];
    
    if (groups.length > units.length) return 'overflow';

    for (let i = 0; i < groups.length; i++) {
        const groupNum = parseInt(groups[i]);
        if (groupNum > 0) {
            const groupIndex = groups.length - 1 - i;
            words += formatGroup(groups[i]) + ' ' + units[groupIndex] + ' ';
        }
    }

    return words.trim().replace(/\s+/g, ' ');
};

const initialFormData: ReceiptData = {
    receiptType: 'إيصال إستلام نقدية',
    receiptNo: '',
    date: new Date().toISOString().slice(0, 16).replace('T', ' '),
    clientName: '',
    nationalId: '',
    amount: 0,
    amountWords: '',
    bundle20000: 0,
    bundle10000: 0,
    bundle5000: 0,
    bundle2000: 0,
    bundle1000: 0,
    bundle500: 0,
    fraction200: 0,
    fraction100: 0,
    fraction50: 0,
    fraction20: 0,
    fraction10: 0,
    fraction5: 0,
    notes: ''
};

const denominationFields: (keyof ReceiptData)[] = [
    'amount', 'bundle20000', 'bundle10000', 'bundle5000', 'bundle2000', 'bundle1000', 'bundle500',
    'fraction200', 'fraction100', 'fraction50', 'fraction20', 'fraction10', 'fraction5'
];


export const ReceiptForm: React.FC<ReceiptFormProps> = ({ onGenerate, onPrint, nextReceiptNumber }) => {
    const [formData, setFormData] = useState<ReceiptData>(initialFormData);
    const [aiPrompt, setAiPrompt] = useState('');
    const [isThinking, setIsThinking] = useState(false);
    const [isGenerating, setIsGenerating] = useState(false);
    const [idCardImage, setIdCardImage] = useState<File | null>(null);
    const [isExtracting, setIsExtracting] = useState(false);
    const [lastGeneratedPdfUrl, setLastGeneratedPdfUrl] = useState<string | null>(null);

    useEffect(() => {
        setFormData(prev => ({ ...prev, receiptNo: nextReceiptNumber }));
    }, [nextReceiptNumber]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        const isNumeric = denominationFields.includes(name as keyof ReceiptData);
        setFormData(prev => ({ ...prev, [name]: isNumeric ? (value === '' ? 0 : Number(value)) : value }));
        setLastGeneratedPdfUrl(null); // Invalidate print button on change
    };
    
    const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value.replace(/,/g, '');
        if (value === '' || /^\d+$/.test(value)) {
           setFormData(prev => ({...prev, amount: value === '' ? 0 : Number(value)}));
        }
        setLastGeneratedPdfUrl(null);
    };
    
    const handleFillWords = useCallback(() => {
        if (formData.amount > 0) {
            const words = amountToWords(formData.amount);
            const capitalizedWords = words.charAt(0).toUpperCase() + words.slice(1);
            setFormData(prev => ({ ...prev, amountWords: `${capitalizedWords} Egyptian pounds only.` }));
        } else {
            setFormData(prev => ({ ...prev, amountWords: '' }));
        }
    }, [formData.amount]);

    const handleGenerateFromText = async () => {
        if (!aiPrompt.trim()) {
            alert("Please enter a description for the receipt.");
            return;
        }
        setIsThinking(true);
        try {
            const parsedData = await parseReceiptFromText(aiPrompt);
            setFormData(prev => ({
                ...prev,
                clientName: parsedData.clientName ?? prev.clientName,
                nationalId: parsedData.nationalId ?? prev.nationalId,
                amount: parsedData.amount ?? prev.amount,
                bundle20000: parsedData.bundle20000 ?? 0,
                bundle10000: parsedData.bundle10000 ?? 0,
                bundle5000: parsedData.bundle5000 ?? 0,
                bundle2000: parsedData.bundle2000 ?? 0,
                bundle1000: parsedData.bundle1000 ?? 0,
                bundle500: parsedData.bundle500 ?? 0,
                fraction200: parsedData.fraction200 ?? 0,
                fraction100: parsedData.fraction100 ?? 0,
                fraction50: parsedData.fraction50 ?? 0,
                fraction20: parsedData.fraction20 ?? 0,
                fraction10: parsedData.fraction10 ?? 0,
                fraction5: parsedData.fraction5 ?? 0,
                notes: parsedData.notes ?? prev.notes,
            }));
            setLastGeneratedPdfUrl(null);
        } catch (error) {
            console.error("AI parsing failed:", error);
            alert("Failed to parse receipt details. Please try rephrasing your request.");
        } finally {
            setIsThinking(false);
        }
    };
    
    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setIdCardImage(e.target.files[0]);
            setLastGeneratedPdfUrl(null);
        }
    };

    const handleExtractDataFromImage = async () => {
        if (!idCardImage) {
            alert("Please upload an ID card image first.");
            return;
        }
        setIsExtracting(true);
        try {
            const reader = new FileReader();
            reader.readAsDataURL(idCardImage);
            reader.onload = async () => {
                const base64Image = (reader.result as string).split(',')[1];
                const extractedData = await extractIdInfoFromImage(base64Image, idCardImage.type);
                if (extractedData.clientName && extractedData.nationalId) {
                    setFormData(prev => ({
                        ...prev,
                        clientName: extractedData.clientName,
                        nationalId: extractedData.nationalId.replace(/\s/g, '') // remove spaces from ID
                    }));
                    setLastGeneratedPdfUrl(null);
                } else {
                    alert("Could not extract information from the image. Please try a clearer image.");
                }
                setIsExtracting(false);
            };
            reader.onerror = (error) => {
                console.error("File reading error:", error);
                alert("Failed to read the image file.");
                setIsExtracting(false);
            };

        } catch (error) {
            console.error("AI Image extraction failed:", error);
            alert("Failed to extract details from the ID card image.");
            setIsExtracting(false);
        }
    };


    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        
        let dataToSubmit = { ...formData };
        if (!dataToSubmit.amountWords && dataToSubmit.amount > 0) {
            const words = amountToWords(dataToSubmit.amount);
            const capitalizedWords = words.charAt(0).toUpperCase() + words.slice(1);
            dataToSubmit.amountWords = `${capitalizedWords} Egyptian pounds only.`;
        }

        setIsGenerating(true);
        const pdfUrl = await onGenerate(dataToSubmit);
        setIsGenerating(false);

        if (pdfUrl) {
            setLastGeneratedPdfUrl(pdfUrl);
            // Reset form for next entry
            setFormData({
                ...initialFormData,
                date: new Date().toISOString().slice(0, 16).replace('T', ' '),
                receiptNo: nextReceiptNumber,
                receiptType: formData.receiptType // Keep the selected receipt type
            });
            setAiPrompt('');
            setIdCardImage(null);
        }
    };
    
    const totalFromDenoms = (formData.bundle20000 * 20000) + (formData.bundle10000 * 10000) +
                            (formData.bundle5000 * 5000) + (formData.bundle2000 * 2000) +
                            (formData.bundle1000 * 1000) + (formData.bundle500 * 500) +
                            (formData.fraction200 * 200) + (formData.fraction100 * 100) +
                            (formData.fraction50 * 50) + (formData.fraction20 * 20) +
                            (formData.fraction10 * 10) + (formData.fraction5 * 5);

    const amountMismatch = formData.amount > 0 && totalFromDenoms > 0 && totalFromDenoms !== formData.amount;


    return (
        <div className="bg-navy-light p-6 rounded-lg shadow-xl">
            <h2 className="text-2xl font-bold text-gold mb-6 border-b-2 border-gold/30 pb-2">Create New Receipt</h2>
            
            <div className="bg-navy p-4 rounded-md mb-6 border border-gold/20">
                <h3 className="text-lg font-semibold text-gold mb-2 flex items-center">
                    <AIcon className="w-6 h-6 mr-2" />
                    Thinking Mode (AI Assistant)
                </h3>
                <p className="text-sm text-silver/80 mb-3">Describe the receipt in plain text, and the AI will fill out the form for you.</p>
                <textarea
                    className="w-full bg-navy-light p-2 rounded-md border border-silver/30 focus:ring-2 focus:ring-gold focus:outline-none"
                    rows={3}
                    placeholder="e.g., 'Receipt for Ahmed Mohamed, ID 29912120101234, for 50,000 EGP. He paid with 2 bundles of 20,000 and 1 bundle of 10,000. Note: For security services.'"
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                    disabled={isThinking}
                />
                <button
                    onClick={handleGenerateFromText}
                    disabled={isThinking}
                    className="mt-3 w-full flex justify-center items-center bg-gold text-navy font-bold py-2 px-4 rounded-md hover:bg-yellow-500 transition-colors disabled:bg-gold/50 disabled:cursor-not-allowed"
                >
                    {isThinking ? <LoadingIcon className="w-5 h-5 animate-spin mr-2" /> : <AIcon className="w-5 h-5 mr-2" />}
                    {isThinking ? 'Thinking...' : 'Generate from Text'}
                </button>
            </div>
            
            <div className="bg-navy p-4 rounded-md mb-6 border border-gold/20">
                <h3 className="text-lg font-semibold text-gold mb-2 flex items-center">
                    <IdCardIcon className="w-6 h-6 mr-2" />
                     ID Card Scanner (AI)
                </h3>
                <p className="text-sm text-silver/80 mb-3">Upload an image of the ID card to automatically extract the Name and National ID.</p>
                <div className="flex items-center space-x-4">
                    <label className="flex-1 block">
                        <span className="sr-only">Choose ID card</span>
                        <input type="file" accept="image/*" onChange={handleImageUpload} className="block w-full text-sm text-silver file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-gold file:text-navy hover:file:bg-yellow-500" />
                    </label>
                    <button
                        onClick={handleExtractDataFromImage}
                        disabled={isExtracting || !idCardImage}
                        className="flex justify-center items-center bg-gold text-navy font-bold py-2 px-4 rounded-md hover:bg-yellow-500 transition-colors disabled:bg-gold/50 disabled:cursor-not-allowed"
                    >
                        {isExtracting ? <LoadingIcon className="w-5 h-5 animate-spin mr-2" /> : <UploadIcon className="w-5 h-5 mr-2" />}
                        {isExtracting ? 'Extracting...' : 'Extract Data'}
                    </button>
                </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="md:col-span-1">
                        <label className="block text-sm font-medium text-silver/90">Receipt No.</label>
                        <input type="text" name="receiptNo" value={formData.receiptNo} onChange={handleChange} required className="mt-1 block w-full bg-navy p-2 rounded-md border border-silver/30 focus:ring-2 focus:ring-gold focus:outline-none" />
                    </div>
                    <div className="md:col-span-1">
                        <label className="block text-sm font-medium text-silver/90">Date</label>
                        <input type="datetime-local" name="date" value={formData.date} onChange={handleChange} required className="mt-1 block w-full bg-navy p-2 rounded-md border border-silver/30 focus:ring-2 focus:ring-gold focus:outline-none" />
                    </div>
                     <div className="md:col-span-1">
                        <label htmlFor="receiptType" className="block text-sm font-medium text-silver/90">Receipt Type</label>
                        <select
                            id="receiptType"
                            name="receiptType"
                            value={formData.receiptType}
                            onChange={handleChange}
                            className="mt-1 block w-full bg-navy p-2 rounded-md border border-silver/30 focus:ring-gold focus:border-gold focus:outline-none"
                        >
                            <option value="إيصال إستلام نقدية">إيصال إستلام نقدية</option>
                            <option value="إيصال صرف نقدية">إيصال صرف نقدية</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label className="block text-sm font-medium text-silver/90">Client Name / Recipient</label>
                    <input type="text" name="clientName" value={formData.clientName} onChange={handleChange} required className="mt-1 block w-full bg-navy p-2 rounded-md border border-silver/30 focus:ring-2 focus:ring-gold focus:outline-none" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-silver/90">National ID / Reference</label>
                    <input type="text" name="nationalId" value={formData.nationalId} onChange={handleChange} required className="mt-1 block w-full bg-navy p-2 rounded-md border border-silver/30 focus:ring-2 focus:ring-gold focus:outline-none" />
                </div>
                
                <div>
                    <label className="block text-sm font-medium text-silver/90">Amount (EGP)</label>
                    <input type="text" name="amount" value={formData.amount > 0 ? formData.amount.toLocaleString() : ''} onChange={handleAmountChange} required className="mt-1 block w-full bg-navy p-2 rounded-md border border-silver/30 focus:ring-2 focus:ring-gold focus:outline-none" />
                </div>

                <div>
                    <label className="block text-sm font-medium text-silver/90">Amount in Words</label>
                     <div className="flex space-x-2 mt-1">
                        <input type="text" name="amountWords" value={formData.amountWords} onChange={handleChange} className="block w-full bg-navy p-2 rounded-md border border-silver/30 focus:ring-2 focus:ring-gold focus:outline-none" />
                        <button type="button" onClick={handleFillWords} className="bg-silver/20 text-silver px-3 rounded-md hover:bg-silver/40" title="Auto-fill amount in words"><FillIcon className="w-5 h-5"/></button>
                    </div>
                </div>
                
                 <div className="bg-navy p-4 rounded-md">
                    <label className="block text-sm font-bold text-silver/90 mb-3">Denominations</label>
                    
                    <div className="mb-4">
                        <h4 className="text-sm font-semibold text-gold mb-2">Bundles (بواكى)</h4>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2">
                            {[20000, 10000, 5000, 2000, 1000, 500].map(val => {
                                const count = formData[`bundle${val}` as keyof ReceiptData] as number;
                                return (
                                <div key={`bundle-${val}`}>
                                    <label className="block text-xs font-medium text-silver/80">{val.toLocaleString()} EGP</label>
                                    <input type="number" name={`bundle${val}`} value={count || ''} onChange={handleChange} min="0" className="mt-1 block w-full bg-navy-light p-2 rounded-md border border-silver/30 focus:ring-2 focus:ring-gold focus:outline-none" />
                                    {count > 0 && (
                                        <p className="text-xs text-gold mt-1 text-right">
                                            Total: {(val * count).toLocaleString()} EGP
                                        </p>
                                    )}
                                </div>
                            )})}
                        </div>
                    </div>

                     <div>
                        <h4 className="text-sm font-semibold text-gold mb-2">Fractions (فركشن)</h4>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2">
                             {[200, 100, 50, 20, 10, 5].map(val => {
                                const count = formData[`fraction${val}` as keyof ReceiptData] as number;
                                return (
                                <div key={`fraction-${val}`}>
                                    <label className="block text-xs font-medium text-silver/80">{val.toLocaleString()} EGP</label>
                                    <input type="number" name={`fraction${val}`} value={count || ''} onChange={handleChange} min="0" className="mt-1 block w-full bg-navy-light p-2 rounded-md border border-silver/30 focus:ring-2 focus:ring-gold focus:outline-none" />
                                    {count > 0 && (
                                        <p className="text-xs text-gold mt-1 text-right">
                                            Total: {(val * count).toLocaleString()} EGP
                                        </p>
                                    )}
                                </div>
                            )})}
                        </div>
                    </div>

                     <div className="mt-4 pt-4 border-t border-silver/20 text-sm text-silver/80">
                         Total from denominations: <span className="font-bold text-silver">{totalFromDenoms.toLocaleString()} EGP</span>
                         {amountMismatch && <p className="text-red-400 font-semibold">Warning: Denomination total does not match amount.</p>}
                     </div>
                </div>
                
                <div>
                    <label className="block text-sm font-medium text-silver/90">Notes</label>
                    <textarea name="notes" value={formData.notes} onChange={handleChange} rows={2} className="mt-1 block w-full bg-navy p-2 rounded-md border border-silver/30 focus:ring-2 focus:ring-gold focus:outline-none" />
                </div>
                
                <div className="flex space-x-4">
                    <button
                        type="submit"
                        disabled={isGenerating}
                        className="w-full flex justify-center items-center bg-green-600 text-white font-bold py-3 px-4 rounded-md hover:bg-green-700 transition-colors disabled:bg-green-800 disabled:cursor-not-allowed"
                    >
                        {isGenerating ? <LoadingIcon className="w-6 h-6 animate-spin mr-2" /> : <GenerateIcon className="w-6 h-6 mr-2" />}
                        {isGenerating ? 'Generating...' : 'Generate & Save PDF'}
                    </button>
                    <button
                        type="button"
                        onClick={() => onPrint(lastGeneratedPdfUrl!)}
                        disabled={!lastGeneratedPdfUrl || isGenerating}
                        className="w-full flex justify-center items-center bg-blue-600 text-white font-bold py-3 px-4 rounded-md hover:bg-blue-700 transition-colors disabled:bg-blue-800 disabled:cursor-not-allowed"
                    >
                        <PrintIcon className="w-6 h-6 mr-2" />
                        Print Last Receipt
                    </button>
                </div>
            </form>
        </div>
    );
};
