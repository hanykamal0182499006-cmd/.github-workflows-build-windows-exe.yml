
import React from 'react';
import type { SavedReceipt, ReceiptData } from '../types';
import { PdfIcon, ExportIcon, DeleteIcon } from './icons';

interface ReceiptListProps {
    receipts: SavedReceipt[];
    onDelete: (id: number) => void;
}

export const ReceiptList: React.FC<ReceiptListProps> = ({ receipts, onDelete }) => {

    const handleExportCSV = () => {
        if (receipts.length === 0) {
            alert("No receipts to export.");
            return;
        }

        // Define headers from ReceiptData type to ensure order and completeness.
        const headers: (keyof ReceiptData)[] = [
            'receiptNo', 'date', 'clientName', 'nationalId', 'amount', 'amountWords',
            'bundle20000', 'bundle10000', 'bundle5000', 'bundle2000', 'bundle1000', 'bundle500',
            'fraction200', 'fraction100', 'fraction50', 'fraction20', 'fraction10', 'fraction5',
            'notes'
        ];

        const csvRows: string[] = [headers.join(',')]; // Header row

        const escapeCSV = (str: string | number) => {
            const s = String(str);
            // Check if the string contains a comma, a double quote, or a newline character.
            if (s.includes(',') || s.includes('"') || s.includes('\n')) {
                // If so, wrap the string in double quotes and escape any existing double quotes by doubling them.
                return `"${s.replace(/"/g, '""')}"`;
            }
            return s;
        };

        receipts.forEach(receipt => {
            const values = headers.map(header => escapeCSV(receipt.receiptData[header]));
            csvRows.push(values.join(','));
        });

        const csvContent = csvRows.join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', `receipt_history_${new Date().toISOString().slice(0,10)}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="bg-navy-light p-6 rounded-lg shadow-xl h-full">
            <div className="flex justify-between items-center mb-6 border-b-2 border-gold/30 pb-2">
                <h2 className="text-2xl font-bold text-gold">Receipt History</h2>
                {receipts.length > 0 && (
                    <button
                        onClick={handleExportCSV}
                        className="flex items-center bg-silver/20 text-silver px-3 py-2 rounded-md hover:bg-silver/40 transition-colors text-sm"
                        title="Export all as CSV"
                    >
                        <ExportIcon className="w-4 h-4 mr-2" />
                        Export CSV
                    </button>
                )}
            </div>

            {receipts.length === 0 ? (
                <div className="text-center py-10">
                    <p className="text-silver/70">No receipts have been generated yet.</p>
                </div>
            ) : (
                <div className="space-y-3 max-h-[80vh] overflow-y-auto pr-2">
                    {receipts.map(receipt => (
                        <div key={receipt.id} className="bg-navy p-4 rounded-md flex justify-between items-center transition-all hover:bg-navy/50 border border-silver/20">
                            <div>
                                <p className="font-bold text-silver">
                                    Receipt #{receipt.receiptData.receiptNo} - <span className="text-gold">{receipt.receiptData.clientName}</span>
                                </p>
                                <p className="text-sm text-silver/70">
                                    {receipt.receiptData.date} - {Number(receipt.receiptData.amount).toLocaleString('en-US', { style: 'currency', currency: 'EGP' })}
                                </p>
                            </div>
                             <div className="flex items-center space-x-2">
                                <a
                                    href={receipt.pdfUrl}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="bg-gold text-navy p-2 rounded-full hover:bg-yellow-500 transition-colors"
                                    title="View PDF"
                                >
                                    <PdfIcon className="w-5 h-5"/>
                                </a>
                                <button
                                    onClick={() => onDelete(receipt.id)}
                                    className="bg-red-600/80 text-white p-2 rounded-full hover:bg-red-600 transition-colors"
                                    title="Delete Receipt"
                                >
                                    <DeleteIcon className="w-5 h-5" />
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};