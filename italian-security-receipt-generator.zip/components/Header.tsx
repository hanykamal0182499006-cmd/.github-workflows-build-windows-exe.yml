
import React from 'react';

interface HeaderProps {
    logo: string;
}

export const Header: React.FC<HeaderProps> = ({ logo }) => {
    return (
        <header className="bg-navy-light shadow-md">
            <div className="container mx-auto p-4 flex justify-between items-center">
                <div className="flex items-center space-x-4">
                     <img src={logo} alt="Company Logo" className="h-12 w-auto object-contain" />
                    <div>
                        <h1 className="text-xl md:text-2xl font-bold text-gold">Italian Security</h1>
                        <p className="text-sm text-silver hidden md:block">Receipt Generation System</p>
                    </div>
                </div>
            </div>
        </header>
    );
};