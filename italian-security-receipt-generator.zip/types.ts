
export interface ReceiptData {
    receiptType: 'إيصال إستلام نقدية' | 'إيصال صرف نقدية';
    receiptNo: string;
    date: string;
    clientName: string;
    nationalId: string;
    amount: number;
    amountWords: string;
    bundle20000: number;
    bundle10000: number;
    bundle5000: number;
    bundle2000: number;
    bundle1000: number;
    bundle500: number;
    fraction200: number;
    fraction100: number;
    fraction50: number;
    fraction20: number;
    fraction10: number;
    fraction5: number;
    notes: string;
}

export interface SavedReceipt {
    id: number;
    pdfUrl: string;
    receiptData: ReceiptData;
}
