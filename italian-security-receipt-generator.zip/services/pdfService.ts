import jsPDF from 'jspdf';
import QRCode from 'qrcode';
import type { ReceiptData } from '../types';

// Using a built-in font
const FONT = 'Helvetica';

const formatCurrency = (n: number) => {
    try {
        return n.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
    } catch {
        return String(n);
    }
};

export const generateReceiptPdf = async (data: ReceiptData, logoBase64: string | null): Promise<Blob> => {
    const doc = new jsPDF({
        orientation: 'p',
        unit: 'mm',
        format: 'a4'
    });

    const width = doc.internal.pageSize.getWidth();
    const height = doc.internal.pageSize.getHeight();
    const margin = 20;

    // 1. Dark background
    doc.setFillColor('#0A1626'); // Navy
    doc.rect(0, 0, width, height, 'F');

    // 2. Watermark
    doc.saveGraphicsState();
    doc.setFont(FONT, 'bold');
    doc.setFontSize(60);
    doc.setTextColor('#C0C6C9'); // Silver
    // FIX: Cast `doc` to `any` to access the `GState` constructor, which is not available on the default `jsPDF` type. This resolves the TypeScript error.
    doc.setGState(new (doc as any).GState({ opacity: 0.08 }));
    doc.text('ITALIAN SECURITY', width / 2, height / 2, { align: 'center', angle: 30 });
    doc.restoreGraphicsState();

    // 3. Logo
    if (logoBase64) {
        try {
            const imgProps = doc.getImageProperties(logoBase64);
            const imgWidth = 40;
            const imgHeight = (imgProps.height * imgWidth) / imgProps.width;
            doc.addImage(logoBase64, 'PNG', margin, margin, imgWidth, imgHeight);
        } catch (e) {
            console.error("Error adding logo to PDF:", e);
        }
    }
    
    // 4. Header Text (Right-aligned)
    doc.setFont(FONT, 'bold');
    doc.setFontSize(18);
    doc.setTextColor('#FFFFFF');
    doc.text('Italian Security Services', width - margin, margin + 5, { align: 'right' });
    doc.setFont(FONT, 'normal');
    doc.setFontSize(12);
    doc.text('& Money Transport', width - margin, margin + 13, { align: 'right' });

    // 5. Receipt Info & Type
    doc.setFont(FONT, 'bold');
    doc.setFontSize(14);
    doc.setTextColor('#C79C2F'); // Gold
    doc.text(`Receipt No: ${data.receiptNo}`, margin, margin + 35);
    
    // Display Receipt Type
    doc.setFontSize(16);
    doc.text(data.receiptType, width / 2, margin + 45, { align: 'center'});

    doc.setFontSize(12);
    doc.setTextColor('#FFFFFF');
    doc.text(`Date: ${data.date}`, width - margin, margin + 35, { align: 'right' });
    
    // 6. Main Content
    let y = margin + 60;
    const lineSpacing = 8;
    
    const clientLabel = data.receiptType === 'إيصال إستلام نقدية' ? 'Received From:' : 'Paid To:';

    doc.setFont(FONT, 'bold');
    doc.setFontSize(13);
    doc.text(`${clientLabel} ${data.clientName}`, margin, y);
    y += lineSpacing;
    
    doc.setFont(FONT, 'normal');
    doc.setFontSize(12);
    doc.text(`National ID / Ref: ${data.nationalId}`, margin, y);
    y += lineSpacing;
    doc.text(`Amount (numerals): ${formatCurrency(data.amount)} EGP`, margin, y);
    y += lineSpacing;
    doc.text('Amount (words):', margin, y);
    const splitWords = doc.splitTextToSize(data.amountWords, width - (margin*2));
    doc.text(splitWords, margin + 35, y);
    y += lineSpacing * (splitWords.length || 1) + 4;
    
    // 7. Denominations Table
    doc.setFont(FONT, 'bold');
    doc.setFontSize(12);
    doc.text('Denomination Details:', margin, y);
    y += lineSpacing - 2;
    
    const bundles = [
        { val: 20000, count: data.bundle20000 }, { val: 10000, count: data.bundle10000 },
        { val: 5000, count: data.bundle5000 }, { val: 2000, count: data.bundle2000 },
        { val: 1000, count: data.bundle1000 }, { val: 500, count: data.bundle500 },
    ];
    
    const fractions = [
        { val: 200, count: data.fraction200 }, { val: 100, count: data.fraction100 },
        { val: 50, count: data.fraction50 }, { val: 20, count: data.fraction20 },
        { val: 10, count: data.fraction10 }, { val: 5, count: data.fraction5 },
    ];

    const hasBundles = bundles.some(b => b.count > 0);
    const hasFractions = fractions.some(f => f.count > 0);

    doc.setFont(FONT, 'normal');
    doc.setFontSize(11);
    const smallLineSpacing = 6;

    if(hasBundles) {
        doc.setFont(FONT, 'bold');
        doc.text('Bundles:', margin + 5, y);
        y += smallLineSpacing;
        doc.setFont(FONT, 'normal');
        for (const item of bundles) {
            if (item.count > 0) {
                doc.text(`${item.val} EGP x ${item.count} = ${formatCurrency(item.val * item.count)}`, margin + 10, y);
                y += smallLineSpacing;
            }
        }
    }

    if(hasFractions) {
        doc.setFont(FONT, 'bold');
        doc.text('Fractions:', margin + 5, y);
        y += smallLineSpacing;
        doc.setFont(FONT, 'normal');
        for (const item of fractions) {
            if (item.count > 0) {
                doc.text(`${item.val} EGP x ${item.count} = ${formatCurrency(item.val * item.count)}`, margin + 10, y);
                y += smallLineSpacing;
            }
        }
    }
    
    y += 2;
    doc.setDrawColor('#C79C2F');
    doc.line(margin, y - 2, width - margin, y - 2);
    
    const totalFromDenoms = bundles.reduce((sum, b) => sum + b.val * b.count, 0) + fractions.reduce((sum, f) => sum + f.val * f.count, 0);
    
    doc.setFont(FONT, 'bold');
    doc.setFontSize(12);
    doc.text(`Denomination Total: ${formatCurrency(totalFromDenoms)} EGP`, margin, y + 2);
    y += lineSpacing;
    doc.text(`Declared Total: ${formatCurrency(data.amount)} EGP`, margin, y + 2);
    y += lineSpacing * 2;
    
    // 8. Notes
    doc.setFont(FONT, 'normal');
    doc.setFontSize(11);
    doc.text('Notes:', margin, y);
    const splitNotes = doc.splitTextToSize(data.notes || 'N/A', width - (margin*2) - 15);
    doc.text(splitNotes, margin + 15, y);
    
    // 9. Signature Area
    const sigY = height - 40;
    doc.text('Recipient Name: _________________________', width - margin - 80, sigY);
    doc.text('Signature: _____________________________', width - margin - 80, sigY + lineSpacing);

    // 10. QR Code
    const qrData = `No:${data.receiptNo};Date:${data.date};Amount:${data.amount};Client:${data.clientName}`;
    try {
        const qrCodeImage = await QRCode.toDataURL(qrData, { errorCorrectionLevel: 'H' });
        doc.addImage(qrCodeImage, 'PNG', margin, height - margin - 30, 30, 30);
    } catch (err) {
        console.error('Failed to generate QR code', err);
    }

    return doc.output('blob');
};