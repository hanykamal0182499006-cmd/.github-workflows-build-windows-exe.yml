
import { GoogleGenAI, Type } from "@google/genai";
import type { ReceiptData } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

const receiptSchema = {
    type: Type.OBJECT,
    properties: {
        clientName: {
            type: Type.STRING,
            description: "The full name of the client or recipient."
        },
        nationalId: {
            type: Type.STRING,
            description: "The national ID or any reference number provided for the client. Should be a string of digits."
        },
        amount: {
            type: Type.NUMBER,
            description: "The total numerical amount of money. Extract only the number."
        },
        bundle20000: { type: Type.NUMBER, description: "The count of 20,000 EGP bundles. Default to 0." },
        bundle10000: { type: Type.NUMBER, description: "The count of 10,000 EGP bundles. Default to 0." },
        bundle5000: { type: Type.NUMBER, description: "The count of 5,000 EGP bundles. Default to 0." },
        bundle2000: { type: Type.NUMBER, description: "The count of 2,000 EGP bundles. Default to 0." },
        bundle1000: { type: Type.NUMBER, description: "The count of 1,000 EGP bundles. Default to 0." },
        bundle500: { type: Type.NUMBER, description: "The count of 500 EGP bundles. Default to 0." },
        fraction200: { type: Type.NUMBER, description: "The count of 200 EGP fractions/bills. Default to 0." },
        fraction100: { type: Type.NUMBER, description: "The count of 100 EGP fractions/bills. Default to 0." },
        fraction50: { type: Type.NUMBER, description: "The count of 50 EGP fractions/bills. Default to 0." },
        fraction20: { type: Type.NUMBER, description: "The count of 20 EGP fractions/bills. Default to 0." },
        fraction10: { type: Type.NUMBER, description: "The count of 10 EGP fractions/bills. Default to 0." },
        fraction5: { type: Type.NUMBER, description: "The count of 5 EGP fractions/bills. Default to 0." },
        notes: {
            type: Type.STRING,
            description: "Any additional notes or comments mentioned in the text."
        },
    },
    required: ["clientName", "nationalId", "amount"]
};

export const parseReceiptFromText = async (prompt: string): Promise<Partial<ReceiptData>> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-pro",
            contents: `Parse the following text and extract the receipt information according to the provided schema. The text may be in English or Arabic. Analyze it carefully to extract all details, especially the counts for each specific bundle (بواكى) and fraction (فركشن) value.

Text to parse: "${prompt}"`,
            config: {
                responseMimeType: "application/json",
                responseSchema: receiptSchema,
                thinkingConfig: {
                    thinkingBudget: 32768,
                },
            },
        });

        const jsonText = response.text.trim();
        const parsedJson = JSON.parse(jsonText);
        return parsedJson as Partial<ReceiptData>;

    } catch (error) {
        console.error("Error calling Gemini API for text parsing:", error);
        throw new Error("Failed to get a valid response from the AI model for text parsing.");
    }
};

const idCardSchema = {
    type: Type.OBJECT,
    properties: {
        clientName: {
            type: Type.STRING,
            description: "The full name of the person on the ID card. It is usually labeled 'الاسم'."
        },
        nationalId: {
            type: Type.STRING,
            description: "The 14-digit national ID number. It is usually labeled 'الرقم القومي'."
        },
    },
    required: ["clientName", "nationalId"]
};

export const extractIdInfoFromImage = async (imageBase64: string, mimeType: string): Promise<Partial<Pick<ReceiptData, 'clientName' | 'nationalId'>>> => {
    try {
        const imagePart = {
            inlineData: {
                data: imageBase64,
                mimeType: mimeType,
            },
        };
        const textPart = {
            text: "Extract the person's full name (الاسم) and the 14-digit national ID number (الرقم القومي) from this Egyptian ID card image. Provide the response in JSON format according to the schema."
        };

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: { parts: [textPart, imagePart] },
            config: {
                responseMimeType: "application/json",
                responseSchema: idCardSchema,
            },
        });

        const jsonText = response.text.trim();
        const parsedJson = JSON.parse(jsonText);
        return parsedJson as Partial<Pick<ReceiptData, 'clientName' | 'nationalId'>>;

    } catch (error) {
        console.error("Error calling Gemini API for image extraction:", error);
        throw new Error("Failed to get a valid response from the AI model for image extraction.");
    }
};
